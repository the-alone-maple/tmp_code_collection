# Product Opportunity Assessment

## Exactly what problem will this solve? (value proposition)

## For whom do we solve that problem? (target market)

## How big is the opportunity? (market size)

## What alternatives are out there? (competitive landscape)

## Why are we best suited to pursue this? (our differentiator)

## Why now? (market window)

## How will we get this product to market? (go-to-market strategy)

## How will we measure success/make money from this product? (metrics/revenue strategy)

## What factors are critical to success? (solution requirements)

## Given the above, what’s the recommendation? (go or no-go)
