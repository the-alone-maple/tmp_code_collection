# Vision

Vision is an aspirational document that describes a specific state of the future. Is meant to advise members of the end goal and keeping them aligned.

Vision documents have a long-term time frame and they can be less specific in terms of actions. They are meant to be directional.

Read more in [Will Larson's: An Elegant Puzzle: Systems of Engineering Management](https://www.amazon.com/Elegant-Puzzle-Systems-Engineering-Management/dp/1732265186).
