## Objective & Key Results

OKRs is a well known framework for setting goals and measuring our success.

By continuously setting new objectives and measuring our success on them, we
ensure our progression.

Read more [here](https://medium.com/startup-tools/okrs-5afdc298bc28)
