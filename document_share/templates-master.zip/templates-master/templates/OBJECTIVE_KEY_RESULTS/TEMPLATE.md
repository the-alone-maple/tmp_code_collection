# OKR

## Owner

Who's owning it. It can be an individual, a team or a whole organisation.

## Objective

Write shortly the goal that you want to achieve.

## Key Results

List all outcomes that you expect to be done for the objective to be considered
done.
