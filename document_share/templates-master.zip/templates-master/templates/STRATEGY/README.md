# Strategy

A Strategy document states the specific steps and actions to be taken for a specific challenge. It describes the challenge and the solution.

Strategy documents are more practical with variable duration. They can been seen as Product Requirements documents but for non-software/product challenges.

Read more in [Richard Rumelt's: Good Strategy Bad Strategy: The Difference and Why it Matters](https://www.amazon.co.uk/Good-Strategy-Bad-Difference-Matters/dp/1846684811).
