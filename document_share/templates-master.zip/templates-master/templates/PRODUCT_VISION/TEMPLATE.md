# Product Vision

## For (target customer)

## Who (statement of need or opportunity)

## The (product name) is a (product category)

## That (key benefit, reason to buy)

## Unlike (primary competitive alternative)

## Our product (statement of primary differentiation)
